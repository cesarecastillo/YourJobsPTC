﻿using System;
using System.Data;
using System.IO;
using System.Web.UI;
using MySql.Data.MySqlClient;

namespace YourJob1
{
    public partial class myprofileform : Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {
            
            
        }

       
                
            
        
    }
}
